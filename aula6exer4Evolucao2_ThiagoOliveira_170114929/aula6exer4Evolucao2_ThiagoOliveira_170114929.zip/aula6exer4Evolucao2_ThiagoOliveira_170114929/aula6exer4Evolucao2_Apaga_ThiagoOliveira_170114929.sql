-- --------  << aula6exer4 >>  ----------
--
--                    SCRIPT DE DELECAO (DDL)
--
-- Data Criacao ...........: 01/08/2022
-- Autor(es) ..............: Thiago França Vale Oliveira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula6exer4
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- ---------------------------------------------------------

-- BASE DE DADOS
USE aula6exer4;


-- TABELAS
DROP TABLE atua;

DROP TABLE PROJETO;

DROP TABLE LOCALIZACAO;

DROP TABLE DEPENDENTE;

DROP TABLE EMPREGADO;

DROP TABLE DEPARTAMENTO;

DROP TABLE GERENTE;