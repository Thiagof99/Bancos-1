-- --------  << aula9extra1 >>  ----------
--
--                    SCRIPT DE DELECAO (DDL)
--
-- Data Criacao ...........: 22/08/2022
-- Autor(es) ..............: Thiago França Vale Oliveira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula8extra1
--
-- PROJETO => 01 Base de Dados
--         => 02 Tabelas
--
-- ---------------------------------------------------------

USE aula9extra1;

DROP TABLE CIDADE;
DROP TABLE ESTADO;