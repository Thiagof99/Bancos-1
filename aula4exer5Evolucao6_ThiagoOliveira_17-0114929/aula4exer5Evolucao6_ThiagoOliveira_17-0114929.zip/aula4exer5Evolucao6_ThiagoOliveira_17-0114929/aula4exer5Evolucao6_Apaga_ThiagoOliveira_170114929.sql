-- --------  << aula4exer5Evolucao6 >>  ----------
--
--                    SCRIPT DE REMOCAO (DDL)
--
-- Data Criacao ...........: 27/07/2022
-- Autor(es) ..............: Thiago França Vale Oliveira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao6
--
--
-- ---------------------------------------------------------

DROP TABLE aula4exer5Evolucao6.contem;
DROP TABLE aula4exer5Evolucao6.MEDICAMENTOS;
DROP TABLE aula4exer5Evolucao6.PRESCRICOES;
DROP TABLE aula4exer5Evolucao6.CONSULTA_atende;
DROP TABLE aula4exer5Evolucao6.possui;
DROP TABLE aula4exer5Evolucao6.ESPECIALIDADES;
DROP TABLE aula4exer5Evolucao6.MEDICOS;
DROP TABLE aula4exer5Evolucao6.PACIENTES;
DROP TABLE aula4exer5Evolucao6.TELEFONES;